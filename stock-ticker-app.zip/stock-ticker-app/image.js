import OpenAI from "openai"

const outputImg = document.getElementById('output-img');

const openai = new OpenAI({
    apiKey: "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",
})

document.getElementById('submit-btn').addEventListener('click', async () => {
    const prompt = document.getElementById("instruction").value 
        generateImage(prompt);
});

async function generateImage(prompt) {
    const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: prompt,
        size:"1024x1024",
        style:"vivid",
        n:1,
        response_format:"b64_json"
    });

console.log(response)
outputImg.innerHTML = `<img src="data:image/png;base64,${response.data[0].b64_json}">`
}
