import { dates } from '../utils/dates.js'

const tickersArr = []

const generateReportBtn = document.querySelector('.generate-report-btn')

generateReportBtn.addEventListener('click', fetchStockData)

document.getElementById('ticker-input-form').addEventListener('submit', (e) => {
    e.preventDefault()
    const tickerInput = document.getElementById('ticker-input')
    if (tickerInput.value.length > 2) {
        generateReportBtn.disabled = false
        const newTickerStr = tickerInput.value
        tickersArr.push(newTickerStr.toUpperCase())
        tickerInput.value = ''
        renderTickers()
    } else {
        const label = document.getElementsByTagName('label')[0]
        label.style.color = 'red'
        label.textContent = 'You must add at least one ticker. A ticker is a 3 letter or more code for a stock. E.g TSLA for Tesla.'
    }
})

function renderTickers() {
    const tickersDiv = document.querySelector('.ticker-choice-display')
    tickersDiv.innerHTML = ''
    tickersArr.forEach((ticker) => {
        const newTickerSpan = document.createElement('span')
        newTickerSpan.textContent = ticker
        newTickerSpan.classList.add('ticker')
        tickersDiv.appendChild(newTickerSpan)
    })
}

// New DOM references (for loading and output)
const loadingArea = document.querySelector('.loading-panel')
const apiMessage = document.getElementById('api-message')
const actionPanel = document.querySelector('.action-panel')
const outputPanel = document.querySelector('.output-panel')

async function fetchStockData() {
    actionPanel.style.display = 'none'
    loadingArea.style.display = 'flex'
    apiMessage.innerText = 'Fetching stock data...'

    try {
        const stockDataPromises = tickersArr.map(async (ticker) => {
            const url = `https://api.polygon.io/v2/aggs/ticker/${ticker}/range/1/day/${dates.startDate}/${dates.endDate}?adjusted=true&apiKey=${import.meta.env.VITE_POLYGON_API_KEY}`
            const response = await fetch(url)
            if (!response.ok) {
                throw new Error(`Error ${response.status} for ${ticker}`)
            }
            const data = await response.json()
            return JSON.stringify(data)  // Convert to string for AI
        })

        const stockDataArray = await Promise.all(stockDataPromises)
        const combinedData = stockDataArray.join('\n\n')  // Separate tickers clearly

        apiMessage.innerText = 'Analyzing with AI...'
        fetchReport(combinedData)
    } catch (err) {
        loadingArea.innerText = 'Error fetching stock data. Check console/API key.'
        console.error(err)
    }
}

async function fetchReport(data) {
    try {
        // Import OpenAI dynamically (works better in browser with Vite)
        const { default: OpenAI } = await import('openai')

        const openai = new OpenAI({
            apiKey: import.meta.env.VITE_OPENAI_API_KEY,
            dangerouslyAllowBrowser: true  // Temporary for client-side testing – remove later!
        })

        const response = await openai.chat.completions.create({
            model: 'gpt-4o-mini',  // Cheap and fast
            messages: [
                {
                    role: 'system',
                    content: 'You are a trading guru. Given JSON stock data over recent days, write a concise report (under 150 words) on performance for each ticker and recommend buy, hold, or sell.'
                },
                {
                    role: 'user',
                    content: `Analyze this stock data:\n${data}`
                }
            ]
        })

        const reportText = response.choices[0].message.content
        renderReport(reportText)
    } catch (err) {
        loadingArea.innerText = 'Error with AI. Check console/API key.'
        console.error(err)
    }
}

function renderReport(output) {
    loadingArea.style.display = 'none'
    outputPanel.innerHTML = '<h3>AI Trading Report</h3><p></p>'
    const reportParagraph = outputPanel.querySelector('p')
    reportParagraph.textContent = output
    outputPanel.style.display = 'flex'
}