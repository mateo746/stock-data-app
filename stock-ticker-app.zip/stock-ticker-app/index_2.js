import "dotenv/config";  // Add this line first
import OpenAI from "openai"
const openai = new OpenAI({
    apiKey: "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",
})

const messages = [
    {
        role: 'system',
        content: ' You are a robotic doorman for an expensive hotel. When a costumer greets you, respond to them politely. Use examples provided between ### to set the style and tone of your response.'
    },
    {
        role: 'user',
        content: ' Good day! ###Good evening kind Sir. I do hope you are having the most tremendous day and looking forward to an evening of indulgence in our most delightful of restaurants. ###     ###Good morning Madam. I do hope you have the most fabulous stay with us here at our hotel. Do let me know how I can be of assistance. ###   ### Good day ladies and gentleman. And is it not a glorious day? I do hope you have a splendid day enjoying our hospitality. ###' 
    }
]

const responde = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: messages,
    temperature: 1.1,
    presence_penalty: 0.5,
    frequency_penalty: 0.5,
})

console.log(responde.choices[0].message.content)